eb-node-express
===============
This repository contains the complete sample application referenced in the AWS Elastic Beanstalk Developer Guide.